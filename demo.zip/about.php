<?php include 'header_menu.php' ;?>
<div class="top_bgcolor">
<h5>HOME/<span>about</span></h5>
</div>
 
 <div class="container">
<div class="row justify-content-center">
<div class="col-md-8">

<div class="author-wrap ">
<img src="image/anim.jpg" class="cover_photo rounded-circle1">
<div class="text">
<h3>Istiaque hashem</h3>
<span class="d-block">Devoloper</span>

<p>Hi, I’m anim. 
I am student of ahsanullah science and engineering univercity 
department of cse, I've done this project with html,css,
javascript,php etc and also use some plugins.
 I'm quietly confident, naturally curious, 
 and perpetually working on improving my chops one design 
 problem at a time.</p>

</div>
</div>

<div class="author-wrap ">
<img src="image/ador.jpg" class="cover_photo rounded-circle1">
<div class="text">
<h3>Almas shahriar Ador</h3>
<span class="d-block">Devoloper</span>
<p>Hi, My name is almas . 
I am student of ahsanullah science and engineering univercity 
department of cse, I'also have done this project with html,css,
javascript,php etc and also use some plugins.
 I'm quietly confident, naturally curious, 
 and perpetually working on improving my chops one design 
 problem at a time.
</p>

</div>
</div>
</div>

<div class="col-lg-4 ">
	<div class="page_widget">
<p>HTML</p>
<div class="container">
  <div class="skills html">90%</div>
</div>

<p>CSS</p>
<div class="container">
  <div class="skills css">80%</div>
</div>

<p>JavaScript</p>
<div class="container">
  <div class="skills js">65%</div>
</div>

<p>PHP</p>
<div class="container">
  <div class="skills php">60%</div>
</div>
</div>
</div>

</div>
</div>

<div class="container-fluid">
<div class="quick_widget">
<div class="row">


<div class="col-lg-6 ">
<h2 class="footer-heading mb-4">Quick Links</h2>
<ul class="list-unstyled">
  <li><a href="index.php">Home</a></li>
<li><a href="blogs.php">Blogs</a></li>
<li><a href="about.php">About Us</a></li>
<li><a href="contact.php">Contact Us</a></li>
</ul>
</div>

<div class="col-lg-6">
<h2 class="footer-heading mb-4">Connect</h2>
<div class=" white mb-5">
<a href="https://www.facebook.com/?stype=lo&jlou=Afe4oHZMNbpJIm2CIKgwrkqfXbPBXp_uVzwjovuGI7W4V0cClyO834bxP8gRaoI4WZs_rCdnHoJlr4beEY2X2CLUeSZiQJkGQn2FT0TMtVo5JA&smuh=25941&lh=Ac-LE4kuhlik1wHN"><span ><i class='fab fa-facebook-square' style='font-size:36px; color:#ffffff;padding:5px;'></i></span></a>
<a href="https://www.instagram.com/accounts/login/"><span ><i class='fab fa-instagram' style='font-size:36px;color:#ffffff;padding:5px;'></i></span></a>
<a href="https://twitter.com/"><span ><i class='fab fa-twitter-square' style='font-size:36px;color:#ffffff;padding:5px;'></i></span></a>
</div>
</div>

</div>
</div>

</div>

<?php include 'footer.php';?>