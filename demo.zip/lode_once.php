<?php

$_SESSION['logoutid']=2;

?>